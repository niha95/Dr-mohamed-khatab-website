function ImageManager(opts){

    this.options = opts !== undefined ? opts : {};

    this.manager = new Vue({
        el: ''
    });

}